CREATE TABLE IF NOT EXISTS public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.conversation_members (
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (conversation_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversation_members TO authenticated;
GRANT ALL ON public.conversation_members TO service_role;
ALTER TABLE public.conversation_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_conversation_member(_conv uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.conversation_members WHERE conversation_id = _conv AND user_id = _user)
$$;
REVOKE EXECUTE ON FUNCTION public.is_conversation_member(uuid, uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.is_conversation_member(uuid, uuid) TO authenticated;

CREATE POLICY "Members view conversations" ON public.conversations FOR SELECT TO authenticated
  USING (public.is_conversation_member(id, auth.uid()) OR created_by = auth.uid());
CREATE POLICY "Authenticated create conversations" ON public.conversations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Creator can update conversations" ON public.conversations FOR UPDATE TO authenticated
  USING (auth.uid() = created_by) WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Creator can delete conversations" ON public.conversations FOR DELETE TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Members view membership rows" ON public.conversation_members FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Self insert membership" ON public.conversation_members FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.created_by = auth.uid()));
CREATE POLICY "Self leave membership" ON public.conversation_members FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS public.chat_invites (
  token text PRIMARY KEY,
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  max_uses int,
  uses int NOT NULL DEFAULT 0,
  revoked boolean NOT NULL DEFAULT false
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_invites TO authenticated;
GRANT ALL ON public.chat_invites TO service_role;
ALTER TABLE public.chat_invites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view invites" ON public.chat_invites FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Members create invites" ON public.chat_invites FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by AND public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Creator updates invites" ON public.chat_invites FOR UPDATE TO authenticated
  USING (auth.uid() = created_by) WITH CHECK (auth.uid() = created_by);

CREATE OR REPLACE FUNCTION public.accept_chat_invite(_token text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv public.chat_invites;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO inv FROM public.chat_invites WHERE token = _token;
  IF NOT FOUND THEN RAISE EXCEPTION 'invite not found'; END IF;
  IF inv.revoked THEN RAISE EXCEPTION 'invite revoked'; END IF;
  IF inv.expires_at IS NOT NULL AND inv.expires_at < now() THEN RAISE EXCEPTION 'invite expired'; END IF;
  IF inv.max_uses IS NOT NULL AND inv.uses >= inv.max_uses THEN RAISE EXCEPTION 'invite exhausted'; END IF;
  INSERT INTO public.conversation_members (conversation_id, user_id) VALUES (inv.conversation_id, uid) ON CONFLICT DO NOTHING;
  UPDATE public.chat_invites SET uses = uses + 1 WHERE token = _token;
  RETURN inv.conversation_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.accept_chat_invite(text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.accept_chat_invite(text) TO authenticated;

CREATE TABLE IF NOT EXISTS public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL,
  kind text NOT NULL CHECK (kind IN ('text','image','video','audio','file')),
  content text,
  media_url text,
  media_name text,
  media_mime text,
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conv ON public.chat_messages(conversation_id, created_at);
GRANT SELECT, INSERT, UPDATE ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view messages" ON public.chat_messages FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Members send messages" ON public.chat_messages FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = sender_id AND public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Sender soft-delete own" ON public.chat_messages FOR UPDATE TO authenticated
  USING (auth.uid() = sender_id) WITH CHECK (auth.uid() = sender_id);
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;

DROP POLICY IF EXISTS "memories_public_select" ON public.memories;
DROP POLICY IF EXISTS "memories_public_insert" ON public.memories;
DROP POLICY IF EXISTS "memories_public_delete" ON public.memories;
REVOKE ALL ON public.memories FROM anon;
CREATE POLICY "memories_auth_select" ON public.memories FOR SELECT TO authenticated USING (true);
CREATE POLICY "memories_auth_insert" ON public.memories FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "memories_auth_delete" ON public.memories FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "memories_storage_select" ON storage.objects;
DROP POLICY IF EXISTS "memories_storage_insert" ON storage.objects;
DROP POLICY IF EXISTS "memories_storage_delete" ON storage.objects;
CREATE POLICY "memories_storage_select" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'memories');
CREATE POLICY "memories_storage_insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'memories');
CREATE POLICY "memories_storage_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'memories' AND owner = auth.uid());