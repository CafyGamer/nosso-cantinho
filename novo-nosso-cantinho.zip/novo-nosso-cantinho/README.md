# Nosso Cantinho

Projeto web baseado no código fornecido, com React, TypeScript, TanStack Start e Supabase.

## Requisitos
- Node.js compatível com Vite 8
- npm
- Projeto Supabase configurado

## Como executar localmente
1. Instale as dependências:
   ```bash
   npm install
   ```
2. Copie `.env.example` para `.env.local` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY` com os dados do seu projeto Supabase.
3. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
4. Para gerar a versão de produção:
   ```bash
   npm run build
   ```

## Importante antes de publicar
- Configure e aplique as migrações do banco de dados no Supabase.
- Revise as políticas RLS de todas as tabelas e as políticas de armazenamento para garantir que memórias, mensagens e arquivos sejam acessíveis apenas às pessoas autorizadas.
- Nunca coloque uma chave `service_role` no frontend. Use somente a chave publicável no cliente.
- As variáveis de ambiente reais não estão incluídas neste pacote.

O projeto foi preparado a partir do ZIP fornecido; a compilação e a integração com um projeto Supabase real ainda precisam ser testadas no ambiente de destino.
