import { supabase } from "@/integrations/supabase/client";

export type Memory = {
  id: string;
  kind: "photo" | "note";
  image_url: string | null;
  caption: string | null;
  note_text: string | null;
  author: string | null;
  user_id: string | null;
  storage_path: string | null;
  created_at: string;
};

const BUCKET = "memories";
const SIGNED_TTL = 60 * 60 * 24 * 365 * 5;

export async function fetchMemories(): Promise<Memory[]> {
  const { data, error } = await supabase
    .from("memories")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Memory[];
}

export async function addNote(author: string, text: string) {
  const { data: u } = await supabase.auth.getUser();
  const { error } = await supabase.from("memories").insert({
    kind: "note",
    note_text: text,
    author: author || null,
    user_id: u.user?.id ?? null,
  });
  if (error) throw error;
}

export async function addPhoto(author: string, caption: string, file: File) {
  const { data: u } = await supabase.auth.getUser();
  const ext = file.name.split(".").pop() || "jpg";
  const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const up = await supabase.storage.from(BUCKET).upload(path, file, {
    contentType: file.type || "image/jpeg",
  });
  if (up.error) throw up.error;

  const signed = await supabase.storage.from(BUCKET).createSignedUrl(path, SIGNED_TTL);
  if (signed.error) throw signed.error;

  const { error } = await supabase.from("memories").insert({
    kind: "photo",
    image_url: signed.data.signedUrl,
    caption: caption || null,
    author: author || null,
    user_id: u.user?.id ?? null,
    storage_path: path,
  });
  if (error) throw error;
}

export async function deleteMemory(m: Memory) {
  if (m.kind === "photo" && m.storage_path) {
    await supabase.storage.from(BUCKET).remove([m.storage_path]);
  }
  const { error } = await supabase.from("memories").delete().eq("id", m.id);
  if (error) throw error;
}

export async function canDelete(m: Memory, userId: string, isOwner: boolean) {
  if (m.user_id === userId) return true;
  if (m.user_id === null && isOwner) return true;
  return false;
}
