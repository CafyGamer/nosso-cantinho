import { supabase } from "@/integrations/supabase/client";

export type ChatMessage = {
  id: string;
  conversation_id: string;
  sender_id: string;
  kind: "text" | "image" | "video" | "audio" | "file";
  content: string | null;
  media_url: string | null;
  media_name: string | null;
  media_mime: string | null;
  created_at: string;
  deleted_at: string | null;
};

export type Conversation = {
  id: string;
  name: string | null;
  created_by: string;
  created_at: string;
};

export type ChatInvite = {
  token: string;
  conversation_id: string;
  created_by: string;
  created_at: string;
  expires_at: string | null;
  max_uses: number | null;
  uses: number;
  revoked: boolean;
};

const BUCKET = "chat-media";
const SIGNED_TTL = 60 * 60 * 24 * 365 * 5;

export async function fetchMessages(conversationId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from("chat_messages")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true })
    .limit(500);
  if (error) throw error;
  return (data ?? []) as ChatMessage[];
}

export async function sendText(conversationId: string, text: string) {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const { error } = await supabase.from("chat_messages").insert({
    conversation_id: conversationId,
    sender_id: u.user.id,
    kind: "text",
    content: text,
  });
  if (error) throw error;
}

export async function sendMedia(
  conversationId: string,
  file: Blob,
  kind: "image" | "video" | "audio" | "file",
  filename: string,
  mime: string,
) {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const ext = filename.includes(".") ? filename.split(".").pop() : mime.split("/").pop() || "bin";
  const path = `${u.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const up = await supabase.storage.from(BUCKET).upload(path, file, { contentType: mime });
  if (up.error) throw up.error;
  const signed = await supabase.storage.from(BUCKET).createSignedUrl(path, SIGNED_TTL);
  if (signed.error) throw signed.error;
  const { error } = await supabase.from("chat_messages").insert({
    conversation_id: conversationId,
    sender_id: u.user.id,
    kind,
    media_url: signed.data.signedUrl,
    media_name: filename,
    media_mime: mime,
  });
  if (error) throw error;
}

export async function deleteMessage(id: string) {
  const { error } = await supabase
    .from("chat_messages")
    .update({ deleted_at: new Date().toISOString(), content: null, media_url: null })
    .eq("id", id);
  if (error) throw error;
}

export function kindFromMime(mime: string): "image" | "video" | "audio" | "file" {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return "file";
}

// --- Conversations ---

export async function listMyConversations(): Promise<Conversation[]> {
  const { data, error } = await supabase
    .from("conversations")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Conversation[];
}

export async function ensureDefaultConversation(): Promise<Conversation> {
  const existing = await listMyConversations();
  if (existing.length > 0) return existing[0];
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const { data, error } = await supabase
    .from("conversations")
    .insert({ name: "Meu chat", created_by: u.user.id })
    .select("*")
    .single();
  if (error) throw error;
  await supabase.from("conversation_members").insert({
    conversation_id: data.id,
    user_id: u.user.id,
  });
  return data as Conversation;
}

export async function createConversation(name: string): Promise<Conversation> {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const { data, error } = await supabase
    .from("conversations")
    .insert({ name: name || "Novo chat", created_by: u.user.id })
    .select("*")
    .single();
  if (error) throw error;
  await supabase.from("conversation_members").insert({
    conversation_id: data.id,
    user_id: u.user.id,
  });
  return data as Conversation;
}

export async function listMembers(conversationId: string) {
  const { data: members, error } = await supabase
    .from("conversation_members")
    .select("user_id, joined_at")
    .eq("conversation_id", conversationId);
  if (error) throw error;
  const ids = (members ?? []).map((m) => m.user_id);
  if (ids.length === 0) return [];
  const { data: profiles } = await supabase
    .from("profiles")
    .select("id, display_name, username, avatar_url")
    .in("id", ids);
  return (profiles ?? []).map((p) => ({
    ...p,
    joined_at: members!.find((m) => m.user_id === p.id)?.joined_at ?? null,
  }));
}

// --- Invites ---

function genToken() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(36).padStart(2, "0")).join("").slice(0, 22);
}

export async function createInvite(conversationId: string, opts?: { expiresInHours?: number; maxUses?: number }) {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const token = genToken();
  const expires_at = opts?.expiresInHours
    ? new Date(Date.now() + opts.expiresInHours * 3600_000).toISOString()
    : null;
  const { data, error } = await supabase
    .from("chat_invites")
    .insert({
      token,
      conversation_id: conversationId,
      created_by: u.user.id,
      expires_at,
      max_uses: opts?.maxUses ?? null,
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as ChatInvite;
}

export async function acceptInvite(token: string): Promise<string> {
  const { data, error } = await supabase.rpc("accept_chat_invite", { _token: token });
  if (error) throw error;
  return data as string;
}

export async function revokeInvite(token: string) {
  const { error } = await supabase.from("chat_invites").update({ revoked: true }).eq("token", token);
  if (error) throw error;
}

export async function listInvites(conversationId: string) {
  const { data, error } = await supabase
    .from("chat_invites")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as ChatInvite[];
}
