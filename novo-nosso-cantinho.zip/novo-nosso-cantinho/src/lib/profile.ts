import { supabase } from "@/integrations/supabase/client";

export type Profile = {
  id: string;
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  is_owner: boolean;
};

const AVATAR_BUCKET = "avatars";
const SIGNED_TTL = 60 * 60 * 24 * 365 * 5;

export async function getMyProfile(): Promise<Profile | null> {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) return null;
  const { data, error } = await supabase
    .from("profiles")
    .select("id, display_name, username, avatar_url, is_owner")
    .eq("id", u.user.id)
    .maybeSingle();
  if (error) throw error;
  return (data ?? null) as Profile | null;
}

export async function getProfiles(ids: string[]): Promise<Profile[]> {
  if (ids.length === 0) return [];
  const { data, error } = await supabase
    .from("profiles")
    .select("id, display_name, username, avatar_url, is_owner")
    .in("id", ids);
  if (error) throw error;
  return (data ?? []) as Profile[];
}

export async function updateProfile(patch: { display_name?: string; username?: string | null; avatar_url?: string | null }) {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const { error } = await supabase.from("profiles").update(patch).eq("id", u.user.id);
  if (error) throw error;
}

export async function uploadAvatar(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) throw new Error("Use uma imagem (foto)");
  if (file.size > 35 * 1024 * 1024) throw new Error("Imagem muito grande (máx 35MB)");
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("Não autenticado");
  const ext = file.name.includes(".") ? file.name.split(".").pop() : (file.type.split("/")[1] || "jpg");
  const path = `${u.user.id}/avatar-${Date.now()}.${ext}`;
  const up = await supabase.storage.from(AVATAR_BUCKET).upload(path, file, { contentType: file.type, upsert: true });
  if (up.error) throw up.error;
  const signed = await supabase.storage.from(AVATAR_BUCKET).createSignedUrl(path, SIGNED_TTL);
  if (signed.error) throw signed.error;
  return signed.data.signedUrl;
}
