import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { FloatingBackground } from "@/components/FloatingBackground";
import { supabase } from "@/integrations/supabase/client";
import { acceptInvite } from "@/lib/chat";

export const Route = createFileRoute("/invite/$token")({
  ssr: false,
  head: () => ({ meta: [{ title: "Convite — Nosso Cantinho" }] }),
  component: InvitePage,
});

function InvitePage() {
  const { token } = useParams({ from: "/invite/$token" });
  const navigate = useNavigate();
  const [status, setStatus] = useState<"checking" | "needs-auth" | "accepting" | "done" | "error">("checking");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) {
        sessionStorage.setItem("pending_invite", token);
        setStatus("needs-auth");
        navigate({ to: "/auth" });
        return;
      }
      setStatus("accepting");
      try {
        const convId = await acceptInvite(token);
        toast.success("Você entrou no chat!");
        setStatus("done");
        navigate({ to: "/chat", search: { c: convId } });
      } catch (e: any) {
        setError(e.message || "Convite inválido");
        setStatus("error");
      }
    })();
  }, [token, navigate]);

  return (
    <>
      <FloatingBackground />
      <main className="relative z-10 mx-auto flex min-h-screen max-w-md items-center justify-center px-4">
        <div className="glow-frame text-center space-y-3">
          {status === "checking" && <p className="italic opacity-80">Verificando convite...</p>}
          {status === "needs-auth" && <p className="italic opacity-80">Entre na sua conta para aceitar o convite.</p>}
          {status === "accepting" && <p className="italic opacity-80">Entrando no chat...</p>}
          {status === "done" && <p className="italic opacity-80">Pronto!</p>}
          {status === "error" && (
            <>
              <p className="text-red-500">{error}</p>
              <button onClick={() => navigate({ to: "/" })} className="rounded-lg bg-[oklch(0.37_0.08_18)] px-4 py-2 text-white">
                Voltar
              </button>
            </>
          )}
        </div>
      </main>
    </>
  );
}
