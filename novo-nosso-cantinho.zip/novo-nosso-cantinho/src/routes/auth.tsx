import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { FloatingBackground } from "@/components/FloatingBackground";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Entrar — Nosso Cantinho" }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  function postLoginRedirect() {
    const pending = typeof window !== "undefined" ? sessionStorage.getItem("pending_invite") : null;
    if (pending) {
      sessionStorage.removeItem("pending_invite");
      navigate({ to: "/invite/$token", params: { token: pending } });
      return;
    }
    navigate({ to: "/" });
  }

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) postLoginRedirect();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleEmail(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: name || email.split("@")[0] }, emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Conta criada! Entrando...");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      postLoginRedirect();
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao entrar");
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) toast.error("Não foi possível entrar com Google");
    else if (!r.redirected) postLoginRedirect();
  }

  return (
    <>
      <FloatingBackground />
      <main className="relative z-10 mx-auto flex min-h-screen max-w-md items-center justify-center px-4">
        <div className="glow-frame w-full space-y-4">
          <h1
            className="gradient-text-left text-center text-4xl"
            style={{ fontFamily: "var(--font-romantic)", lineHeight: 1.25, paddingBlock: "0.15em" }}
          >
            Nosso Cantinho
          </h1>
          <p className="text-center text-sm opacity-80 italic">
            {mode === "signin" ? "Entre para continuar" : "Crie sua conta"}
          </p>

          <button
            onClick={handleGoogle}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-white px-3 py-2 font-medium text-gray-800 transition hover:brightness-95"
          >
            <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.6-6 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 8 3l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3 0 5.8 1.1 8 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2c-2 1.4-4.5 2.4-7.2 2.4-5.3 0-9.7-3.4-11.3-8l-6.5 5C9.6 39.6 16.3 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.1-4.1 5.6l6.2 5.2C41 35.6 44 30.2 44 24c0-1.2-.1-2.3-.4-3.5z"/></svg>
            Entrar com Google
          </button>

          <div className="flex items-center gap-2 text-xs opacity-60">
            <div className="h-px flex-1 bg-current opacity-30" />
            ou
            <div className="h-px flex-1 bg-current opacity-30" />
          </div>

          <form onSubmit={handleEmail} className="space-y-2">
            {mode === "signup" && (
              <input
                type="text"
                placeholder="Seu nome"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
              />
            )}
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
            />
            <input
              type="password"
              placeholder="Senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
            />
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-lg bg-[var(--color-primary)] py-2 font-medium text-[var(--color-primary-foreground)] transition hover:brightness-110 disabled:opacity-60"
            >
              {busy ? "..." : mode === "signin" ? "Entrar" : "Criar conta"}
            </button>
          </form>

          <button
            type="button"
            onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            className="w-full text-center text-sm underline opacity-80"
          >
            {mode === "signin" ? "Não tem conta? Criar uma" : "Já tem conta? Entrar"}
          </button>
        </div>
      </main>
    </>
  );
}
