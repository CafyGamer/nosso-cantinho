import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Camera } from "lucide-react";
import { FloatingBackground } from "@/components/FloatingBackground";
import { getMyProfile, updateProfile, uploadAvatar, type Profile } from "@/lib/profile";
import { AvatarCropper } from "@/components/AvatarCropper";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Perfil — Nosso Cantinho" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getMyProfile().then((p) => {
      if (!p) return;
      setProfile(p);
      setDisplayName(p.display_name ?? "");
      setUsername(p.username ?? "");
      setAvatarUrl(p.avatar_url);
    });
  }, []);

  const [pendingFile, setPendingFile] = useState<File | null>(null);

  function handleAvatar(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("Use uma imagem (foto)");
      return;
    }
    setPendingFile(f);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function handleCropConfirm(cropped: File) {
    setPendingFile(null);
    setUploading(true);
    try {
      const url = await uploadAvatar(cropped);
      setAvatarUrl(url);
      await updateProfile({ avatar_url: url });
      toast.success("Foto atualizada");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!displayName.trim()) {
      toast.error("Digite um nome");
      return;
    }
    setSaving(true);
    try {
      await updateProfile({
        display_name: displayName.trim(),
        username: username.trim() || null,
      });
      toast.success("Perfil salvo");
      navigate({ to: "/" });
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <FloatingBackground />
      <main className="relative z-10 mx-auto max-w-md px-4 py-6">
        <header className="flex items-center gap-3 mb-6">
          <Link to="/" className="rounded-full p-2 hover:bg-white/10"><ArrowLeft size={20} /></Link>
          <h1 className="gradient-text-left text-3xl" style={{ fontFamily: "var(--font-romantic)" }}>
            Seu perfil
          </h1>
        </header>

        <form onSubmit={handleSave} className="glow-frame space-y-5">
          <div className="flex flex-col items-center gap-3">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="relative h-28 w-28 rounded-full overflow-hidden bg-[oklch(0.42_0.1_240)] ring-4 ring-[oklch(0.77_0.03_14)] disabled:opacity-50"
              title="Trocar foto"
            >
              {avatarUrl ? (
                <img src={avatarUrl} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-3xl text-white">
                  {(displayName || "?").charAt(0).toUpperCase()}
                </div>
              )}
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition">
                <Camera size={26} className="text-white" />
              </div>
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              onChange={handleAvatar}
              className="hidden"
            />
            <p className="text-xs opacity-70 italic">apenas fotos · até 35MB</p>
          </div>

          <label className="block space-y-1">
            <span className="text-sm opacity-90">Nome</span>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
              maxLength={60}
              className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm opacity-90">Nome de usuário <span className="opacity-60">(opcional)</span></span>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              maxLength={30}
              placeholder="@seu_user"
              className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
            />
          </label>

          <button
            type="submit"
            disabled={saving}
            className="w-full rounded-lg bg-[var(--color-primary)] py-2 font-medium text-[var(--color-primary-foreground)] transition hover:brightness-110 disabled:opacity-60"
          >
            {saving ? "Salvando..." : "Salvar"}
          </button>
        </form>
      </main>
      {pendingFile && (
        <AvatarCropper
          file={pendingFile}
          onCancel={() => setPendingFile(null)}
          onConfirm={handleCropConfirm}
        />
      )}
    </>
  );
}
