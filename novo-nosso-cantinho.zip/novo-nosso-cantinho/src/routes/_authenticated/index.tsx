import { createFileRoute, Link } from "@tanstack/react-router";
import { MessageCircle, User, Users } from "lucide-react";
import { CountdownTimer } from "@/components/CountdownTimer";
import { FloatingBackground } from "@/components/FloatingBackground";
import { GradientDivider } from "@/components/GradientDivider";
import { MemoryWall } from "@/components/MemoryWall";

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({
    meta: [
      { title: "Nosso Cantinho — Memórias & Cronômetro" },
      { name: "description", content: "Um espaço romântico para guardar fotos, recadinhos e marcar o tempo juntos desde 22/11/2025." },
    ],
  }),
  component: Home,
});

function Home() {

  return (
    <>
      <FloatingBackground />
      <main className="relative z-10 mx-auto max-w-6xl px-4 pt-6 pb-28 sm:py-16">
        <div className="mb-6 flex items-center justify-end gap-2 sm:absolute sm:right-6 sm:top-6 sm:mb-0">
          <Link
            to="/contacts"
            title="Contatos"
            className="rounded-full bg-[oklch(0.37_0.08_18)] p-2 text-[oklch(0.97_0.02_12)] shadow-md transition hover:brightness-110"
          >
            <Users size={18} />
          </Link>
          <Link
            to="/profile"
            title="Perfil"
            className="rounded-full bg-[oklch(0.37_0.08_18)] p-2 text-[oklch(0.97_0.02_12)] shadow-md transition hover:brightness-110"
          >
            <User size={18} />
          </Link>
        </div>

        <header className="text-center mb-10 sm:mb-12">
          <h1
            className="gradient-text-left text-5xl sm:text-7xl"
            style={{ fontFamily: "var(--font-romantic)", lineHeight: 1.25, paddingBlock: "0.25em" }}
          >
            Nosso Cantinho
          </h1>
          <GradientDivider />
          <p className="mt-3 text-base sm:text-lg opacity-80 italic">
            um lugarzinho só nosso para guardar o tempo e as memórias
          </p>
        </header>

        <section className="mb-14">
          <CountdownTimer />
        </section>

        <MemoryWall />

        <footer className="mt-16 text-center text-xs opacity-70">
          Feito com carinho ♥
        </footer>
      </main>

      {/* Floating chat button — alto o bastante para não cobrir o botão Compartilhar */}
      <Link
        to="/chat"
        search={{}}
        className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[oklch(0.42_0.1_240)] text-[oklch(0.98_0.01_240)] shadow-xl ring-2 ring-[oklch(0.98_0.01_240_/_0.3)] transition hover:scale-110"
        title="Abrir chat"
      >
        <MessageCircle size={26} />
      </Link>
    </>
  );
}
