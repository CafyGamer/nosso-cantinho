import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Download, Images, Link2, Mic, Paperclip, Send, StopCircle, Trash2, Users, X } from "lucide-react";
import { FloatingBackground } from "@/components/FloatingBackground";
import { supabase } from "@/integrations/supabase/client";
import {
  ChatMessage,
  Conversation,
  deleteMessage,
  ensureDefaultConversation,
  fetchMessages,
  kindFromMime,
  listMyConversations,
  sendMedia,
  sendText,
  createInvite,
  listMembers,
} from "@/lib/chat";
import { getProfiles, type Profile } from "@/lib/profile";

type Search = { c?: string };

export const Route = createFileRoute("/_authenticated/chat")({
  ssr: false,
  head: () => ({ meta: [{ title: "Chat — Nosso Cantinho" }] }),
  validateSearch: (s: Record<string, unknown>): Search => ({
    c: typeof s.c === "string" ? s.c : undefined,
  }),
  component: ChatPage,
});

function ChatPage() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const [me, setMe] = useState<string | null>(null);
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<ChatMessage[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [showMedia, setShowMedia] = useState(false);
  const [showMembers, setShowMembers] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const cancelRef = useRef(false);
  const timerRef = useRef<number | null>(null);
  const [recSecs, setRecSecs] = useState(0);
  const [viewer, setViewer] = useState<ChatMessage | null>(null);

  // Pending invite redirect
  useEffect(() => {
    const pending = typeof window !== "undefined" ? sessionStorage.getItem("pending_invite") : null;
    if (pending) {
      sessionStorage.removeItem("pending_invite");
      window.location.href = `/invite/${pending}`;
    }
  }, []);

  // Bootstrap: ensure user has at least one conversation
  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      setMe(u.user?.id ?? null);
      try {
        let list = await listMyConversations();
        if (list.length === 0) {
          await ensureDefaultConversation();
          list = await listMyConversations();
        }
        setConvs(list);
        const wanted = search.c && list.find((c) => c.id === search.c)?.id;
        const id = wanted ?? list[0]?.id ?? null;
        setActiveId(id);
        if (id && id !== search.c) navigate({ to: "/chat", search: { c: id }, replace: true });
      } catch (e: any) {
        toast.error(e.message);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load messages + subscribe per conversation
  useEffect(() => {
    if (!activeId) return;
    fetchMessages(activeId).then(setMsgs).catch((e) => toast.error(e.message));
    const ch = supabase
      .channel(`chat-${activeId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_messages", filter: `conversation_id=eq.${activeId}` },
        (payload) => {
          if (payload.eventType === "INSERT") setMsgs((p) => [...p, payload.new as ChatMessage]);
          else if (payload.eventType === "UPDATE")
            setMsgs((p) => p.map((m) => (m.id === (payload.new as ChatMessage).id ? (payload.new as ChatMessage) : m)));
          else if (payload.eventType === "DELETE")
            setMsgs((p) => p.filter((m) => m.id !== (payload.old as ChatMessage).id));
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [activeId]);

  // Load profiles for sender ids
  useEffect(() => {
    const ids = Array.from(new Set(msgs.map((m) => m.sender_id))).filter((id) => !profiles[id]);
    if (ids.length === 0) return;
    getProfiles(ids).then((ps) => {
      setProfiles((prev) => {
        const next = { ...prev };
        ps.forEach((p) => (next[p.id] = p));
        return next;
      });
    });
  }, [msgs, profiles]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  const activeConv = useMemo(() => convs.find((c) => c.id === activeId) ?? null, [convs, activeId]);

  async function handleSendText(e: React.FormEvent) {
    e.preventDefault();
    if (!activeId) return;
    const t = text.trim();
    if (!t) return;
    setText("");
    try {
      await sendText(activeId, t);
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f || !activeId) return;
    if (f.size > 2 * 1024 * 1024 * 1024) {
      toast.error("Arquivo muito grande (máx. 2GB)");
      return;
    }
    setBusy(true);
    try {
      await sendMedia(activeId, f, kindFromMime(f.type || "application/octet-stream"), f.name, f.type || "application/octet-stream");
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function startRecording() {
    if (!activeId) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
      const rec = new MediaRecorder(stream, { mimeType: mime });
      chunksRef.current = [];
      cancelRef.current = false;
      rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (cancelRef.current) return;
        const blob = new Blob(chunksRef.current, { type: mime });
        if (blob.size === 0) return;
        setBusy(true);
        try {
          await sendMedia(activeId, blob, "audio", `audio-${Date.now()}.${mime.split("/")[1]}`, mime);
        } catch (e: any) {
          toast.error(e.message);
        } finally {
          setBusy(false);
        }
      };
      rec.start();
      recorderRef.current = rec;
      setRecSecs(0);
      timerRef.current = window.setInterval(() => setRecSecs((s) => s + 1), 1000);
      setRecording(true);
    } catch {
      toast.error("Não foi possível acessar o microfone");
    }
  }

  function stopRecording() {
    recorderRef.current?.stop();
    recorderRef.current = null;
    if (timerRef.current) window.clearInterval(timerRef.current);
    setRecording(false);
  }

  function cancelRecording() {
    cancelRef.current = true;
    stopRecording();
  }

  async function handleDelete(id: string) {
    if (!confirm("Apagar esta mensagem?")) return;
    try {
      await deleteMessage(id);
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  function downloadMedia(url: string, name: string) {
    const a = document.createElement("a");
    a.href = url;
    a.download = name || "media";
    a.target = "_blank";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function handleInvite() {
    if (!activeId) return;
    try {
      const inv = await createInvite(activeId, { expiresInHours: 24 * 7 });
      const url = `${window.location.origin}/invite/${inv.token}`;
      await navigator.clipboard.writeText(url).catch(() => {});
      toast.success("Link copiado! Válido por 7 dias.");
      prompt("Compartilhe este link:", url);
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  const mediaMsgs = msgs.filter((m) => !m.deleted_at && m.media_url && (m.kind === "image" || m.kind === "video" || m.kind === "audio" || m.kind === "file"));

  return (
    <>
      <FloatingBackground />
      <main className="relative z-10 mx-auto flex h-screen max-w-3xl flex-col px-4 py-4">
        <header className="flex items-center gap-2 border-b border-white/10 pb-3">
          <Link to="/" className="rounded-full p-2 hover:bg-white/10"><ArrowLeft size={20} /></Link>
          <div className="flex-1 min-w-0">
            <h1 className="gradient-text-left text-2xl truncate" style={{ fontFamily: "var(--font-romantic)" }}>
              {activeConv?.name ?? "Chat"}
            </h1>
            {convs.length > 1 && (
              <select
                value={activeId ?? ""}
                onChange={(e) => navigate({ to: "/chat", search: { c: e.target.value } })}
                className="mt-1 rounded bg-[oklch(0.77_0.03_14)] px-2 py-1 text-xs"
              >
                {convs.map((c) => (
                  <option key={c.id} value={c.id}>{c.name ?? "Sem nome"}</option>
                ))}
              </select>
            )}
          </div>
          <button onClick={() => setShowMembers(true)} title="Membros" className="rounded-full p-2 hover:bg-white/10"><Users size={18} /></button>
          <button onClick={() => setShowMedia(true)} title="Mídias" className="rounded-full p-2 hover:bg-white/10"><Images size={18} /></button>
          <button onClick={handleInvite} title="Convidar" className="rounded-full p-2 hover:bg-white/10"><Link2 size={18} /></button>
        </header>

        <div className="flex-1 space-y-2 overflow-y-auto py-4">
          {msgs.length === 0 && (
            <p className="text-center opacity-60 mt-10 italic">Mande o primeiro recadinho 💌</p>
          )}
          {msgs.map((m) => {
            const mine = m.sender_id === me;
            const deleted = !!m.deleted_at;
            const p = profiles[m.sender_id];
            return (
              <div key={m.id} className={`group flex items-end gap-2 ${mine ? "justify-end" : "justify-start"}`}>
                {!mine && (
                  <div className="h-7 w-7 shrink-0 rounded-full overflow-hidden bg-[oklch(0.42_0.1_240)] flex items-center justify-center text-white text-xs">
                    {p?.avatar_url ? <img src={p.avatar_url} className="h-full w-full object-cover" alt="" /> : (p?.display_name || "?").charAt(0).toUpperCase()}
                  </div>
                )}
                <div
                  className={`relative max-w-[75%] rounded-2xl px-3 py-2 shadow ${
                    mine ? "bg-[oklch(0.42_0.1_240)] text-white" : "bg-[oklch(0.77_0.03_14)] text-foreground"
                  }`}
                >
                  {!mine && p && <p className="text-[10px] font-semibold opacity-80 mb-1">{p.display_name ?? "Anônimo"}</p>}
                  {deleted ? (
                    <p className="italic opacity-60 text-sm">mensagem apagada</p>
                  ) : (
                    <>
                      {m.kind === "text" && <p className="whitespace-pre-wrap break-words">{m.content}</p>}
                      {m.kind === "image" && m.media_url && (
                        <button type="button" onClick={() => setViewer(m)} className="block">
                          <img src={m.media_url} alt="" className="max-h-80 rounded-lg cursor-zoom-in" loading="lazy" />
                        </button>
                      )}
                      {m.kind === "video" && m.media_url && (
                        <video src={m.media_url} controls playsInline preload="metadata" className="max-h-80 max-w-full rounded-lg" />
                      )}
                      {m.kind === "audio" && m.media_url && (
                        <audio src={m.media_url} controls className="w-56" />
                      )}
                      {m.kind === "file" && m.media_url && (
                        <a href={m.media_url} target="_blank" rel="noopener" className="underline">
                          📎 {m.media_name || "arquivo"}
                        </a>
                      )}
                      <div className="mt-1 flex items-center justify-end gap-2 text-[10px] opacity-70">
                        <span>{new Date(m.created_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</span>
                        {m.media_url && (
                          <button
                            type="button"
                            onClick={() => downloadMedia(m.media_url!, m.media_name || "media")}
                            title="Salvar"
                          >
                            <Download size={12} />
                          </button>
                        )}
                        {mine && (
                          <button type="button" onClick={() => handleDelete(m.id)} title="Apagar">
                            <Trash2 size={12} />
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        {busy && <p className="pb-2 text-center text-xs opacity-80 animate-pulse">Enviando mídia...</p>}
        {recording && (
          <div className="flex items-center justify-center gap-3 pb-2 text-sm">
            <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
            Gravando {String(Math.floor(recSecs / 60)).padStart(2, "0")}:{String(recSecs % 60).padStart(2, "0")}
            <button type="button" onClick={cancelRecording} className="underline opacity-80">Cancelar</button>
          </div>
        )}
        <form onSubmit={handleSendText} className="flex items-center gap-2 border-t border-white/10 pt-3">
          <input ref={fileRef} type="file" accept="image/*,video/*,audio/*" onChange={handleFile} className="hidden" />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={busy || recording || !activeId}
            className="rounded-full bg-[var(--color-primary)] p-2 text-[var(--color-primary-foreground)] disabled:opacity-50"
            title="Anexar"
          >
            <Paperclip size={18} />
          </button>
          <button
            type="button"
            onClick={recording ? stopRecording : startRecording}
            disabled={busy || !activeId}
            className={`rounded-full p-2 text-[var(--color-primary-foreground)] disabled:opacity-50 ${recording ? "bg-red-600 animate-pulse" : "bg-[var(--color-primary)]"}`}
            title={recording ? "Parar gravação" : "Gravar áudio"}
          >
            {recording ? <StopCircle size={18} /> : <Mic size={18} />}
          </button>
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={recording ? "Gravando áudio..." : "Mensagem"}
            disabled={recording || !activeId}
            className="flex-1 rounded-full bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-4 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
          />
          <button
            type="submit"
            disabled={busy || recording || !text.trim() || !activeId}
            className="rounded-full bg-[var(--color-primary)] p-2 text-[var(--color-primary-foreground)] disabled:opacity-50"
            title="Enviar"
          >
            <Send size={18} />
          </button>
        </form>
      </main>

      {viewer?.media_url && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4" onClick={() => setViewer(null)}>
          <img src={viewer.media_url} alt="" className="max-h-full max-w-full rounded-lg" />
          <div className="absolute right-4 top-4 flex gap-2">
            <button type="button" onClick={(e) => { e.stopPropagation(); downloadMedia(viewer.media_url!, viewer.media_name || "foto"); }} className="rounded-full bg-white/20 p-2 text-white" title="Salvar"><Download size={20} /></button>
            <button type="button" onClick={() => setViewer(null)} className="rounded-full bg-white/20 p-2 text-white" title="Fechar"><X size={20} /></button>
          </div>
        </div>
      )}

      {showMedia && (
        <Modal onClose={() => setShowMedia(false)} title="Mídias do chat">
          {mediaMsgs.length === 0 ? (
            <p className="opacity-60 italic">Nenhuma mídia enviada ainda.</p>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {mediaMsgs.map((m) => (
                <div key={m.id} className="relative group">
                  {m.kind === "image" && <img src={m.media_url!} className="aspect-square object-cover rounded" alt="" />}
                  {m.kind === "video" && <video src={m.media_url!} className="aspect-square object-cover rounded" />}
                  {m.kind === "audio" && <div className="aspect-square rounded bg-[oklch(0.42_0.1_240)] flex items-center justify-center text-white text-xs">🎵</div>}
                  {m.kind === "file" && <div className="aspect-square rounded bg-[oklch(0.42_0.1_240)] flex items-center justify-center text-white text-xs p-1 text-center break-all">{m.media_name}</div>}
                  <button
                    type="button"
                    onClick={() => downloadMedia(m.media_url!, m.media_name || "media")}
                    className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition rounded"
                    title="Salvar"
                  >
                    <Download size={20} className="text-white" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {showMembers && activeId && (
        <Modal onClose={() => setShowMembers(false)} title="Membros">
          <MembersList conversationId={activeId} />
          <button
            type="button"
            onClick={handleInvite}
            className="mt-3 w-full rounded-lg bg-[oklch(0.42_0.1_240)] py-2 text-white flex items-center justify-center gap-2"
          >
            <Link2 size={16} /> Gerar link de convite
          </button>
        </Modal>
      )}
    </>
  );
}

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div className="w-full max-w-md max-h-[80vh] overflow-y-auto rounded-2xl bg-[oklch(0.2_0.02_280)] p-4 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button onClick={onClose} className="rounded-full p-1 hover:bg-white/10"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function MembersList({ conversationId }: { conversationId: string }) {
  const [members, setMembers] = useState<any[]>([]);
  useEffect(() => {
    listMembers(conversationId).then(setMembers).catch(() => {});
  }, [conversationId]);
  return (
    <ul className="space-y-2">
      {members.map((m) => (
        <li key={m.id} className="flex items-center gap-3 rounded-lg bg-[oklch(0.77_0.03_14)] px-2 py-2">
          <div className="h-9 w-9 rounded-full overflow-hidden bg-[oklch(0.42_0.1_240)] flex items-center justify-center text-white text-sm">
            {m.avatar_url ? <img src={m.avatar_url} className="h-full w-full object-cover" alt="" /> : (m.display_name || "?").charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{m.display_name ?? "Sem nome"}</p>
            {m.username && <p className="text-xs opacity-60 truncate">@{m.username}</p>}
          </div>
        </li>
      ))}
    </ul>
  );
}
