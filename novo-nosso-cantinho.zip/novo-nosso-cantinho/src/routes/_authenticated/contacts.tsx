import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, MessageCircle, Plus } from "lucide-react";
import { FloatingBackground } from "@/components/FloatingBackground";
import { supabase } from "@/integrations/supabase/client";
import {
  listMyConversations,
  listMembers,
  createConversation,
  type Conversation,
} from "@/lib/chat";

export const Route = createFileRoute("/_authenticated/contacts")({
  head: () => ({ meta: [{ title: "Contatos — Nosso Cantinho" }] }),
  component: ContactsPage,
});

type Contact = {
  id: string;
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  conversation_id: string;
  conversation_name: string | null;
};

function ContactsPage() {
  const [me, setMe] = useState<string | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      setMe(u.user?.id ?? null);
      const conversations = await listMyConversations();
      setConvs(conversations);
      const seen = new Set<string>();
      const list: Contact[] = [];
      for (const c of conversations) {
        const members = await listMembers(c.id);
        for (const m of members) {
          if (m.id === u.user?.id) continue;
          const key = `${c.id}:${m.id}`;
          if (seen.has(key)) continue;
          seen.add(key);
          list.push({
            id: m.id,
            display_name: (m as any).display_name ?? null,
            username: (m as any).username ?? null,
            avatar_url: (m as any).avatar_url ?? null,
            conversation_id: c.id,
            conversation_name: c.name,
          });
        }
      }
      setContacts(list);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleNewChat() {
    const name = prompt("Nome do novo chat:");
    if (!name) return;
    try {
      const c = await createConversation(name);
      toast.success("Chat criado");
      window.location.href = `/chat?c=${c.id}`;
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  return (
    <>
      <FloatingBackground />
      <main className="relative z-10 mx-auto max-w-2xl px-4 py-6">
        <header className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Link to="/" className="rounded-full p-2 hover:bg-white/10"><ArrowLeft size={20} /></Link>
            <h1 className="gradient-text-left text-3xl" style={{ fontFamily: "var(--font-romantic)" }}>
              Contatos
            </h1>
          </div>
          <button
            onClick={handleNewChat}
            title="Novo chat"
            className="rounded-full bg-[oklch(0.42_0.1_240)] p-2 text-white shadow"
          >
            <Plus size={18} />
          </button>
        </header>

        {loading && <p className="text-center opacity-60 italic">Carregando...</p>}

        {!loading && convs.length === 0 && (
          <div className="glow-frame text-center space-y-3">
            <p className="italic opacity-80">Você ainda não tem nenhum chat.</p>
            <button
              onClick={handleNewChat}
              className="rounded-lg bg-[oklch(0.37_0.08_18)] px-4 py-2 font-medium text-white"
            >
              Criar primeiro chat
            </button>
          </div>
        )}

        {!loading && convs.length > 0 && (
          <section className="space-y-2 mb-6">
            <h2 className="text-sm uppercase tracking-wide opacity-60">Suas conversas</h2>
            {convs.map((c) => (
              <Link
                key={c.id}
                to="/chat"
                search={{ c: c.id }}
                className="flex items-center justify-between rounded-lg bg-[oklch(0.77_0.03_14)] px-3 py-2 hover:brightness-110"
              >
                <span className="font-medium">{c.name ?? "Sem nome"}</span>
                <MessageCircle size={18} />
              </Link>
            ))}
          </section>
        )}

        {!loading && contacts.length > 0 && (
          <section className="space-y-2">
            <h2 className="text-sm uppercase tracking-wide opacity-60">Pessoas</h2>
            {contacts.map((c) => (
              <Link
                key={`${c.conversation_id}:${c.id}`}
                to="/chat"
                search={{ c: c.conversation_id }}
                className="flex items-center gap-3 rounded-lg bg-[oklch(0.77_0.03_14)] px-3 py-2 hover:brightness-110"
              >
                <div className="h-10 w-10 rounded-full overflow-hidden bg-[oklch(0.42_0.1_240)] flex items-center justify-center text-white">
                  {c.avatar_url ? (
                    <img src={c.avatar_url} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span>{(c.display_name || "?").charAt(0).toUpperCase()}</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{c.display_name ?? "Sem nome"}</p>
                  {c.username && <p className="text-xs opacity-60 truncate">@{c.username}</p>}
                </div>
                <span className="text-xs opacity-60 truncate max-w-[40%]">{c.conversation_name}</span>
              </Link>
            ))}
          </section>
        )}

        {!loading && convs.length > 0 && contacts.length === 0 && (
          <p className="text-center opacity-60 italic mt-4">
            Nenhuma outra pessoa nas suas conversas ainda. Crie um convite no chat para adicionar alguém.
          </p>
        )}
      </main>
    </>
  );
}
