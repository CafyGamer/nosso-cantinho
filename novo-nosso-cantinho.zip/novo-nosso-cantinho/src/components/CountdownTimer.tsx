import { useEffect, useState } from "react";

const START = new Date(2025, 10, 22, 0, 0, 0); // 22/11/2025 local

function diff(now: Date) {
  let years = now.getFullYear() - START.getFullYear();
  let months = now.getMonth() - START.getMonth();
  let days = now.getDate() - START.getDate();
  let hours = now.getHours() - START.getHours();
  let minutes = now.getMinutes() - START.getMinutes();
  let seconds = now.getSeconds() - START.getSeconds();

  if (seconds < 0) { seconds += 60; minutes -= 1; }
  if (minutes < 0) { minutes += 60; hours -= 1; }
  if (hours < 0)   { hours += 24;   days -= 1; }
  if (days < 0) {
    const prev = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
    days += prev; months -= 1;
  }
  if (months < 0) { months += 12; years -= 1; }

  if (years < 0) {
    return { years: 0, months: 0, days: 0, hours: 0, minutes: 0, seconds: 0 };
  }
  return { years, months, days, hours, minutes, seconds };
}

export function CountdownTimer() {
  const [t, setT] = useState<ReturnType<typeof diff> | null>(null);
  useEffect(() => {
    setT(diff(new Date()));
    const id = setInterval(() => setT(diff(new Date())), 1000);
    return () => clearInterval(id);
  }, []);

  const cells: [string, number][] = t
    ? [
        ["anos", t.years],
        ["meses", t.months],
        ["dias", t.days],
        ["horas", t.hours],
        ["min", t.minutes],
        ["seg", t.seconds],
      ]
    : [["anos", 0], ["meses", 0], ["dias", 0], ["horas", 0], ["min", 0], ["seg", 0]];

  return (
    <div className="glow-frame mx-auto max-w-3xl">
      <p className="text-center text-sm tracking-widest uppercase opacity-90" style={{ color: "oklch(0.2 0.05 15)" }}>
        Juntos desde <span className="text-lg font-semibold">22</span> de novembro de <span className="text-lg font-semibold">2025</span>
      </p>
      <div className="mt-4 grid grid-cols-3 sm:grid-cols-6 gap-3">
        {cells.map(([label, value]) => (
          <div
            key={label}
            className="rounded-xl bg-[var(--preview-bg)] py-3 text-center shadow-inner border border-[var(--input-border)]"
          >
            <div className="text-3xl sm:text-4xl font-semibold tabular-nums text-[var(--input-text)]">
              {String(value).padStart(2, "0")}
            </div>
            <div className="text-[0.7rem] uppercase tracking-wider opacity-80 mt-1">
              {label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
