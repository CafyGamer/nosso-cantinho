import { useMemo } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

type Shape = "heart" | "circle" | "flower" | "sparkle" | "star" | "ring";

const BIG_SHAPES: Shape[] = ["heart", "circle", "flower", "ring", "heart", "flower"];
const SMALL_SHAPES: Shape[] = ["sparkle", "star", "heart", "circle"];

// Tons pastéis azul e amarelo
const COLORS = [
  "oklch(0.64 0.08 250)",
  "oklch(0.70 0.07 245)",
  "oklch(0.60 0.09 255)",
  "oklch(0.77 0.10 85)",
  "oklch(0.74 0.09 90)",
  "oklch(0.80 0.08 80)",
  "oklch(0.67 0.08 230)",
  "oklch(0.72 0.09 70)",
];

const FLOAT_CLASSES = ["float-a", "float-b", "float-c"];

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

function ShapeSvg({ kind, color }: { kind: Shape; color: string }) {
  switch (kind) {
    case "heart":
      return (
        <svg viewBox="0 0 24 24" fill={color}>
          <path d="M12 21s-7-4.35-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6C19 16.65 12 21 12 21z" />
        </svg>
      );
    case "circle":
      return (
        <svg viewBox="0 0 24 24" fill={color}>
          <circle cx="12" cy="12" r="10" />
        </svg>
      );
    case "ring":
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2">
          <circle cx="12" cy="12" r="9" />
        </svg>
      );
    case "flower":
      return (
        <svg viewBox="0 0 24 24" fill={color}>
          <circle cx="12" cy="5" r="3.2" />
          <circle cx="12" cy="19" r="3.2" />
          <circle cx="5" cy="12" r="3.2" />
          <circle cx="19" cy="12" r="3.2" />
          <circle cx="7" cy="7" r="2.6" />
          <circle cx="17" cy="7" r="2.6" />
          <circle cx="7" cy="17" r="2.6" />
          <circle cx="17" cy="17" r="2.6" />
          <circle cx="12" cy="12" r="2.6" fill="oklch(0.62 0.12 80)" />
        </svg>
      );
    case "star":
      return (
        <svg viewBox="0 0 24 24" fill={color}>
          <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.8-6.2 3.8 1.6-7L2 9.2l7.1-.6z" />
        </svg>
      );
    case "sparkle":
      return (
        <svg viewBox="0 0 24 24" fill={color}>
          <path d="M12 2l2 8 8 2-8 2-2 8-2-8-8-2 8-2z" />
        </svg>
      );
  }
}

function spread(count: number, rand: () => number, minDist: number, taken: { top: number; left: number }[] = []) {
  const out: { top: number; left: number }[] = [];
  let attempts = 0;
  while (out.length < count && attempts < count * 120) {
    attempts++;
    const top = rand() * 100;
    const left = rand() * 100;
    const all = [...taken, ...out];
    if (all.every((p) => Math.hypot(top - p.top, left - p.left) >= minDist)) out.push({ top, left });
  }
  while (out.length < count) out.push({ top: rand() * 100, left: rand() * 100 });
  return out;
}

export function FloatingBackground() {
  const isMobile = useIsMobile();

  const { big, small, blobs } = useMemo(() => {
    const rand = rng(11);
    const bigCount = isMobile ? 9 : 16;
    const smallCount = isMobile ? 14 : 28;

    const bigPos = spread(bigCount, rand, isMobile ? 22 : 18);
    const smallPos = spread(smallCount, rand, isMobile ? 9 : 7, bigPos);

    const big = bigPos.map((p, i) => ({
      ...p,
      i,
      kind: BIG_SHAPES[Math.floor(rand() * BIG_SHAPES.length)],
      color: COLORS[Math.floor(rand() * COLORS.length)],
      size: (isMobile ? 60 : 90) + Math.floor(rand() * (isMobile ? 60 : 120)),
      opacity: 0.2 + rand() * 0.14,
      rotate: Math.floor(rand() * 40 - 20),
      float: FLOAT_CLASSES[i % 3],
      delay: -rand() * 10,
    }));

    const small = smallPos.map((p, i) => ({
      ...p,
      i,
      kind: SMALL_SHAPES[Math.floor(rand() * SMALL_SHAPES.length)],
      color: COLORS[Math.floor(rand() * COLORS.length)],
      size: (isMobile ? 14 : 18) + Math.floor(rand() * (isMobile ? 16 : 24)),
      opacity: 0.35 + rand() * 0.25,
      rotate: Math.floor(rand() * 60 - 30),
      float: FLOAT_CLASSES[(i + 1) % 3],
      delay: -rand() * 10,
    }));

    const blobs = [
      { top: 8, left: 10, size: 520, color: "oklch(0.70 0.08 250 / 0.35)" },
      { top: 70, left: 85, size: 560, color: "oklch(0.80 0.09 85 / 0.32)" },
      { top: 45, left: 50, size: 640, color: "oklch(0.74 0.06 20 / 0.25)" },
      { top: 90, left: 15, size: 420, color: "oklch(0.78 0.08 90 / 0.28)" },
      { top: 15, left: 88, size: 440, color: "oklch(0.68 0.08 240 / 0.28)" },
    ];

    return { big, small, blobs };
  }, [isMobile]);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden" style={{ zIndex: 0 }}>
      {/* manchas de luz suaves */}
      {blobs.map((b, i) => (
        <div
          key={`b${i}`}
          className={FLOAT_CLASSES[i % 3]}
          style={{
            position: "absolute",
            top: `${b.top}%`,
            left: `${b.left}%`,
            width: isMobile ? b.size * 0.6 : b.size,
            height: isMobile ? b.size * 0.6 : b.size,
            transform: "translate(-50%, -50%)",
            borderRadius: "9999px",
            background: `radial-gradient(circle, ${b.color} 0%, transparent 70%)`,
            filter: "blur(30px)",
          }}
        />
      ))}

      {[...big.map((x) => ({ ...x, blur: 0.5, key: `g${x.i}` })), ...small.map((x) => ({ ...x, blur: 0, key: `s${x.i}` }))].map(
        (it) => (
          <div
            key={it.key}
            style={{
              position: "absolute",
              top: `${it.top}%`,
              left: `${it.left}%`,
              width: it.size,
              height: it.size,
              marginLeft: -it.size / 2,
              marginTop: -it.size / 2,
              opacity: it.opacity,
              transform: `rotate(${it.rotate}deg)`,
            }}
          >
            <div
              className={it.float}
              style={{
                width: "100%",
                height: "100%",
                animationDelay: `${it.delay}s`,
                filter: `blur(${it.blur}px) drop-shadow(0 0 8px ${it.color})`,
              }}
            >
              <ShapeSvg kind={it.kind} color={it.color} />
            </div>
          </div>
        ),
      )}

      {/* vinheta leve para manter o texto legível */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 0%, transparent 55%, oklch(0.78 0.045 12 / 0.35) 100%)",
        }}
      />
    </div>
  );
}
