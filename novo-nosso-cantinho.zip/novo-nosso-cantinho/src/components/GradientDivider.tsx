export function GradientDivider() {
  return (
    <div className="flex justify-center py-3">
      <div
        className="h-[2px] w-[90%] max-w-3xl rounded-full"
        style={{
          background: "var(--gradient-edge)",
          filter:
            "drop-shadow(0 0 10px oklch(0.5 0.15 240 / 0.75)) drop-shadow(0 0 22px oklch(0.62 0.16 85 / 0.65)) drop-shadow(0 0 38px oklch(0.5 0.15 240 / 0.35))",
          animation: "edge-shimmer 5s ease-in-out infinite",
        }}
      />
    </div>
  );
}
