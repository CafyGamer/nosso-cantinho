import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Download, Trash2 } from "lucide-react";
import { GradientDivider } from "@/components/GradientDivider";
import { addNote, addPhoto, deleteMemory, fetchMemories, type Memory } from "@/lib/memories";
import { supabase } from "@/integrations/supabase/client";

const MAX_IMAGE_BYTES = 35 * 1024 * 1024; // 35MB
const MAX_VIDEO_BYTES = 2 * 1024 * 1024 * 1024; // 2GB
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime", "video/ogg"];
const VIDEO_EXTS = ["mp4", "webm", "mov", "ogg", "ogv", "m4v"];

const authorSchema = z
  .string()
  .trim()
  .min(1, { message: "O nome é obrigatório" })
  .max(50, { message: "O nome deve ter no máximo 50 caracteres" });

const noteSchema = z.object({
  author: authorSchema,
  text: z
    .string()
    .trim()
    .min(1, { message: "Escreva um recadinho antes de enviar" })
    .max(500, { message: "O recado deve ter no máximo 500 caracteres" }),
});

const photoSchema = z.object({
  author: authorSchema,
  caption: z
    .string()
    .trim()
    .max(150, { message: "A legenda deve ter no máximo 150 caracteres" }),
});

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString("pt-BR", {
      day: "2-digit", month: "short", year: "numeric",
    });
  } catch { return ""; }
}

function formatBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / (1024 * 1024)).toFixed(1)} MB`;
}

function isVideoUrl(url: string) {
  const clean = url.split("?")[0].toLowerCase();
  return VIDEO_EXTS.some((ext) => clean.endsWith("." + ext));
}

type FileValidation =
  | { state: "idle" }
  | { state: "ok"; kind: "image" | "video"; message: string }
  | { state: "error"; message: string };

function validateFile(file: File): FileValidation {
  const isImg = ALLOWED_IMAGE_TYPES.includes(file.type);
  const isVid = ALLOWED_VIDEO_TYPES.includes(file.type);
  if (!isImg && !isVid) {
    return { state: "error", message: "Formato inválido. Use imagem (JPG, PNG, WEBP, GIF) ou vídeo (MP4, WEBM, MOV)" };
  }
  if (isImg && file.size > MAX_IMAGE_BYTES) {
    return { state: "error", message: `Imagem muito grande (${formatBytes(file.size)}). Máx. 35MB` };
  }
  if (isVid && file.size > MAX_VIDEO_BYTES) {
    return { state: "error", message: `Vídeo muito grande (${formatBytes(file.size)}). Máx. 2GB` };
  }
  return {
    state: "ok",
    kind: isImg ? "image" : "video",
    message: `${isImg ? "Imagem" : "Vídeo"} válido • ${formatBytes(file.size)}`,
  };
}

export function MemoryWall() {
  const [items, setItems] = useState<Memory[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [author, setAuthor] = useState("");
  const [me, setMe] = useState<string | null>(null);
  const [isOwner, setIsOwner] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      const uid = data.user?.id ?? null;
      setMe(uid);
      if (uid) {
        const { data: p } = await supabase.from("profiles").select("display_name,is_owner").eq("id", uid).maybeSingle();
        if (p?.is_owner) setIsOwner(true);
        if (p?.display_name) setAuthor(p.display_name);
      }
    })();
  }, []);

  const [noteText, setNoteText] = useState("");
  const [caption, setCaption] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [fileValidation, setFileValidation] = useState<FileValidation>({ state: "idle" });

  // Live note validation
  const noteValidation = useMemo(() => {
    if (!noteText.trim() && !author) return { state: "idle" as const };
    const parsed = noteSchema.safeParse({ author, text: noteText });
    if (!parsed.success) {
      return { state: "error" as const, message: parsed.error.issues[0]?.message ?? "Inválido" };
    }
    return { state: "ok" as const, message: `${parsed.data.text.length}/500 caracteres` };
  }, [author, noteText]);

  // Generate object URL preview
  useEffect(() => {
    if (!file) {
      setFilePreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setFilePreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  async function refresh() {
    try {
      const data = await fetchMemories();
      setItems(data);
      setErr(null);
    } catch (e: any) {
      setErr(e.message ?? "Erro ao carregar memórias");
    } finally { setLoading(false); }
  }

  useEffect(() => { refresh(); }, []);

  async function handleDelete(m: Memory) {
    if (!confirm("Apagar esta memória?")) return;
    try {
      await deleteMemory(m);
      toast.success("Memória apagada");
      setItems((prev) => prev.filter((x) => x.id !== m.id));
    } catch (e: any) {
      toast.error(e.message ?? "Não foi possível apagar");
    }
  }

  function downloadUrl(url: string, name: string) {
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.target = "_blank";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }


  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0] ?? null;
    setFile(f);
    if (!f) {
      setFileValidation({ state: "idle" });
      return;
    }
    setFileValidation(validateFile(f));
  }

  function clearFile() {
    setFile(null);
    setFileValidation({ state: "idle" });
    if (fileRef.current) fileRef.current.value = "";
  }

  async function handleNote(e: React.FormEvent) {
    e.preventDefault();
    const parsed = noteSchema.safeParse({ author, text: noteText });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Dados inválidos");
      return;
    }
    setSubmitting(true);
    try {
      await addNote(parsed.data.author, parsed.data.text);
      setNoteText("");
      toast.success("Recadinho enviado com carinho 💌");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message ?? "Não foi possível enviar o recado");
    }
    finally { setSubmitting(false); }
  }

  async function handlePhoto(e: React.FormEvent) {
    e.preventDefault();
    if (!file) {
      toast.error("Selecione uma imagem ou vídeo para enviar");
      return;
    }
    const fv = validateFile(file);
    if (fv.state !== "ok") {
      toast.error(fv.state === "error" ? fv.message : "Arquivo inválido");
      return;
    }
    const parsed = photoSchema.safeParse({ author, caption });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Dados inválidos");
      return;
    }
    setSubmitting(true);
    try {
      await addPhoto(parsed.data.author, parsed.data.caption, file);
      setCaption("");
      clearFile();
      toast.success(fv.kind === "video" ? "Vídeo compartilhado com sucesso 💖" : "Foto compartilhada com sucesso 💖");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message ?? "Não foi possível enviar");
    }
    finally { setSubmitting(false); }
  }

  // Validation UI helpers
  const ringClass = (s: FileValidation["state"] | "idle" | "ok" | "error") => {
    if (s === "ok") return "ring-2 ring-[oklch(0.55_0.15_150)]";
    if (s === "error") return "ring-2 ring-[oklch(0.55_0.2_27)]";
    return "";
  };

  return (
    <div className="space-y-10">
      <div className="grid gap-6 md:grid-cols-2">
        {/* Photo / Video form */}
        <form onSubmit={handlePhoto} className="glow-frame space-y-3">
          <h3 className="text-xl font-semibold">Adicionar foto ou vídeo</h3>
          <input
            type="text"
            placeholder="Seu nome"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
          />
          <input
            ref={fileRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleFileChange}
            className={`w-full rounded-lg text-sm text-transparent file:mr-3 file:rounded-lg file:border-0 file:bg-[var(--color-primary)] file:px-3 file:py-2 file:text-[var(--color-primary-foreground)] ${ringClass(fileValidation.state)}`}
          />

          {/* File preview */}
          {file && filePreview && (
            <div className="space-y-2">
              <div className="overflow-hidden rounded-lg bg-[var(--preview-bg)]">
                {fileValidation.state === "ok" && fileValidation.kind === "video" ? (
                  <video
                    src={filePreview}
                    controls
                    className="w-full max-h-64 object-contain"
                  />
                ) : (
                  <img
                    src={filePreview}
                    alt="Pré-visualização"
                    className="w-full max-h-64 object-contain"
                  />
                )}
              </div>
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="truncate opacity-90">{file.name}</span>
                <button
                  type="button"
                  onClick={clearFile}
                  className="shrink-0 rounded px-2 py-1 underline opacity-90 hover:opacity-100"
                >
                  Remover
                </button>
              </div>
            </div>
          )}

          {/* File validation message */}
          {fileValidation.state === "error" && (
            <p className="text-sm text-[oklch(0.55_0.2_27)]">⚠ {fileValidation.message}</p>
          )}
          {fileValidation.state === "ok" && (
            <p className="text-sm text-[oklch(0.5_0.15_150)]">✓ {fileValidation.message}</p>
          )}
          {!file && fileValidation.state === "idle" && (
            <p className="text-sm italic opacity-80">Só pode enviar se algum arquivo for adicionado</p>
          )}

          <input
            type="text"
            placeholder="Legenda (opcional)"
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
          />
          <button
            type="submit"
            disabled={submitting || fileValidation.state !== "ok" || !file || !authorSchema.safeParse(author).success}
            className="w-full rounded-lg bg-[var(--color-primary)] py-2 font-medium text-[var(--color-primary-foreground)] transition hover:brightness-110 disabled:opacity-60"
          >
            {submitting ? "Enviando..." : "Compartilhar"}
          </button>
        </form>

        {/* Note form */}
        <form onSubmit={handleNote} className="glow-frame space-y-3">
          <h3 className="text-xl font-semibold">Deixar um recadinho</h3>
          <input
            type="text"
            placeholder="Seu nome"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            className="w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)]"
          />
          <textarea
            placeholder="Escreva aqui..."
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            rows={4}
            className={`w-full rounded-lg bg-[var(--input-bg)] text-[var(--input-text)] placeholder:text-[var(--input-placeholder)] border border-[var(--input-border)] px-3 py-2 outline-none focus:ring-2 focus:ring-[oklch(0.55_0.12_240)] resize-none ${ringClass(noteValidation.state)}`}
          />

          {/* Note preview */}
          {noteText.trim() && noteValidation.state !== "error" && (
            <div className="rounded-lg bg-[var(--preview-bg)] p-3">
              <p className="mb-1 text-xs uppercase tracking-wider opacity-80">Pré-visualização</p>
              <p className="whitespace-pre-wrap text-base italic leading-relaxed">
                “{noteText.trim()}”
              </p>
              {author.trim() && (
                <p className="mt-2 text-xs uppercase tracking-wider opacity-80">— {author.trim()}</p>
              )}
            </div>
          )}

          {/* Note validation message */}
          {noteValidation.state === "error" && (
            <p className="text-sm text-[oklch(0.55_0.2_27)]">⚠ {noteValidation.message}</p>
          )}
          {noteValidation.state === "ok" && (
            <p className="text-sm text-[oklch(0.5_0.15_150)]">✓ {noteValidation.message}</p>
          )}

          <button
            type="submit"
            disabled={submitting || noteValidation.state !== "ok"}
            className="w-full rounded-lg bg-[var(--color-primary)] py-2 font-medium text-[var(--color-primary-foreground)] transition hover:brightness-110 disabled:opacity-60"
          >
            {submitting ? "Enviando..." : "Compartilhar recado"}
          </button>
        </form>
      </div>

      {err && (
        <p className="text-center text-sm text-[oklch(0.32_0.18_27)]">{err}</p>
      )}

      <GradientDivider />

      <section>
        <h2 className="text-center text-2xl mb-6 gradient-text-right" style={{ fontFamily: "var(--font-romantic)" }}>
          Nossas memórias
        </h2>
        {loading ? (
          <p className="text-center opacity-70">Carregando...</p>
        ) : items.length === 0 ? (
          <p className="text-center opacity-70">Ainda não há memórias. Seja o primeiro!</p>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((m) => (
              <article key={m.id} className="glow-frame">
                {m.kind === "photo" && m.image_url ? (
                  isVideoUrl(m.image_url) ? (
                    <video
                      src={m.image_url}
                      controls
                      className="w-full rounded-lg object-cover aspect-[4/3] bg-black"
                      preload="metadata"
                    />
                  ) : (
                    <img
                      src={m.image_url}
                      alt={m.caption ?? "Foto"}
                      className="w-full rounded-lg object-cover aspect-[4/3]"
                      loading="lazy"
                    />
                  )
                ) : (
                  <p className="whitespace-pre-wrap text-lg italic leading-relaxed">
                    “{m.note_text}”
                  </p>
                )}
                {m.kind === "photo" && m.caption && (
                  <p className="mt-3 text-sm italic">{m.caption}</p>
                )}
                <div className="mt-3 flex items-center justify-between gap-2">
                  <p className="text-xs uppercase tracking-wider opacity-70">
                    {m.author ? `${m.author} • ` : ""}{formatDate(m.created_at)}
                  </p>
                  <div className="flex gap-1">
                    {m.kind === "photo" && m.image_url && (
                      <button
                        type="button"
                        onClick={() => downloadUrl(m.image_url!, m.caption || "memoria")}
                        title="Baixar"
                        className="rounded p-1 opacity-70 hover:opacity-100"
                      >
                        <Download size={14} />
                      </button>
                    )}
                    {(m.user_id === me || (m.user_id === null && isOwner)) && (
                      <button
                        type="button"
                        onClick={() => handleDelete(m)}
                        title="Apagar"
                        className="rounded p-1 text-[oklch(0.55_0.2_27)] opacity-70 hover:opacity-100"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
