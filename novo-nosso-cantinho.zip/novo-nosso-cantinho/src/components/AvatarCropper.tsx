import { useCallback, useEffect, useState } from "react";
import Cropper, { type Area } from "react-easy-crop";
import { X, RotateCw, ZoomIn } from "lucide-react";

type Props = {
  file: File;
  onCancel: () => void;
  onConfirm: (cropped: File) => void;
};

async function getCroppedBlob(
  src: string,
  area: Area,
  rotation: number,
  outputSize = 512,
): Promise<Blob> {
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.crossOrigin = "anonymous";
    i.onload = () => resolve(i);
    i.onerror = reject;
    i.src = src;
  });

  // Rotate around center on an offscreen canvas, then crop.
  const rad = (rotation * Math.PI) / 180;
  const sin = Math.abs(Math.sin(rad));
  const cos = Math.abs(Math.cos(rad));
  const bW = img.width * cos + img.height * sin;
  const bH = img.width * sin + img.height * cos;

  const rotated = document.createElement("canvas");
  rotated.width = bW;
  rotated.height = bH;
  const rctx = rotated.getContext("2d")!;
  rctx.translate(bW / 2, bH / 2);
  rctx.rotate(rad);
  rctx.drawImage(img, -img.width / 2, -img.height / 2);

  const out = document.createElement("canvas");
  out.width = outputSize;
  out.height = outputSize;
  const octx = out.getContext("2d")!;
  octx.drawImage(
    rotated,
    area.x,
    area.y,
    area.width,
    area.height,
    0,
    0,
    outputSize,
    outputSize,
  );

  return await new Promise<Blob>((resolve, reject) =>
    out.toBlob((b) => (b ? resolve(b) : reject(new Error("Falha ao gerar imagem"))), "image/jpeg", 0.92),
  );
}

export function AvatarCropper({ file, onCancel, onConfirm }: Props) {
  const [src, setSrc] = useState<string>("");
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [area, setArea] = useState<Area | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    setSrc(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const onComplete = useCallback((_: Area, pixels: Area) => setArea(pixels), []);

  async function handleConfirm() {
    if (!area) return;
    setBusy(true);
    try {
      const blob = await getCroppedBlob(src, area, rotation, 512);
      const out = new File([blob], `avatar-${Date.now()}.jpg`, { type: "image/jpeg" });
      onConfirm(out);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="w-full max-w-md rounded-2xl bg-[oklch(0.78_0.045_12)] p-4 shadow-2xl">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-semibold">Ajuste sua foto</h3>
          <button onClick={onCancel} className="rounded-full p-1 hover:bg-black/10">
            <X size={20} />
          </button>
        </div>

        <div className="relative h-72 w-full overflow-hidden rounded-lg bg-black">
          {src && (
            <Cropper
              image={src}
              crop={crop}
              zoom={zoom}
              rotation={rotation}
              aspect={1}
              cropShape="round"
              showGrid={false}
              onCropChange={setCrop}
              onZoomChange={setZoom}
              onRotationChange={setRotation}
              onCropComplete={onComplete}
            />
          )}
        </div>

        <div className="mt-4 space-y-3">
          <label className="flex items-center gap-2 text-sm">
            <ZoomIn size={16} />
            <input
              type="range"
              min={1}
              max={4}
              step={0.01}
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="flex-1"
            />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <RotateCw size={16} />
            <input
              type="range"
              min={0}
              max={360}
              step={1}
              value={rotation}
              onChange={(e) => setRotation(Number(e.target.value))}
              className="flex-1"
            />
          </label>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 rounded-lg bg-[oklch(0.77_0.03_14)] py-2 font-medium"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={busy || !area}
            className="flex-1 rounded-lg bg-[oklch(0.37_0.08_18)] py-2 font-medium text-[oklch(0.97_0.02_12)] disabled:opacity-60"
          >
            {busy ? "Processando..." : "Usar esta foto"}
          </button>
        </div>
      </div>
    </div>
  );
}
