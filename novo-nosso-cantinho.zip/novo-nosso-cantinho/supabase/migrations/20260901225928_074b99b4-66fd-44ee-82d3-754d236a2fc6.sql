create table if not exists public.memories (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('photo','note')),
  image_url text,
  caption text,
  note_text text,
  author text,
  user_id uuid,
  storage_path text,
  created_at timestamptz not null default now()
);

grant select, insert, delete on public.memories to anon;
grant select, insert, update, delete on public.memories to authenticated;
grant all on public.memories to service_role;

alter table public.memories enable row level security;

create policy "memories_public_select" on public.memories for select to anon, authenticated using (true);
create policy "memories_public_insert" on public.memories for insert to anon, authenticated with check (true);
create policy "memories_public_delete" on public.memories for delete to anon, authenticated using (true);