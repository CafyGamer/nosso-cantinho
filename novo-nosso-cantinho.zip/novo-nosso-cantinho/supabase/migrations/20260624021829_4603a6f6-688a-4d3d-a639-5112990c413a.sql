
-- Conversations
CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.conversation_members (
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (conversation_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversation_members TO authenticated;
GRANT ALL ON public.conversation_members TO service_role;
ALTER TABLE public.conversation_members ENABLE ROW LEVEL SECURITY;

-- Helper to avoid recursive RLS
CREATE OR REPLACE FUNCTION public.is_conversation_member(_conv uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversation_members
    WHERE conversation_id = _conv AND user_id = _user
  )
$$;

CREATE POLICY "Members view conversations" ON public.conversations FOR SELECT TO authenticated
  USING (public.is_conversation_member(id, auth.uid()));
CREATE POLICY "Authenticated create conversations" ON public.conversations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Creator can update conversations" ON public.conversations FOR UPDATE TO authenticated
  USING (auth.uid() = created_by) WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Creator can delete conversations" ON public.conversations FOR DELETE TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Members view membership rows" ON public.conversation_members FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Self insert membership" ON public.conversation_members FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Self leave membership" ON public.conversation_members FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- Invites
CREATE TABLE public.chat_invites (
  token text PRIMARY KEY,
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  max_uses int,
  uses int NOT NULL DEFAULT 0,
  revoked boolean NOT NULL DEFAULT false
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_invites TO authenticated;
GRANT ALL ON public.chat_invites TO service_role;
ALTER TABLE public.chat_invites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated view invites" ON public.chat_invites FOR SELECT TO authenticated USING (true);
CREATE POLICY "Members create invites" ON public.chat_invites FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by AND public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Creator updates invites" ON public.chat_invites FOR UPDATE TO authenticated
  USING (auth.uid() = created_by) WITH CHECK (auth.uid() = created_by);

-- Accept invite RPC (security definer to bypass member-only insert restrictions)
CREATE OR REPLACE FUNCTION public.accept_chat_invite(_token text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv public.chat_invites;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;
  SELECT * INTO inv FROM public.chat_invites WHERE token = _token;
  IF NOT FOUND THEN RAISE EXCEPTION 'invite not found'; END IF;
  IF inv.revoked THEN RAISE EXCEPTION 'invite revoked'; END IF;
  IF inv.expires_at IS NOT NULL AND inv.expires_at < now() THEN RAISE EXCEPTION 'invite expired'; END IF;
  IF inv.max_uses IS NOT NULL AND inv.uses >= inv.max_uses THEN RAISE EXCEPTION 'invite exhausted'; END IF;
  INSERT INTO public.conversation_members (conversation_id, user_id)
    VALUES (inv.conversation_id, uid) ON CONFLICT DO NOTHING;
  UPDATE public.chat_invites SET uses = uses + 1 WHERE token = _token;
  RETURN inv.conversation_id;
END;
$$;
GRANT EXECUTE ON FUNCTION public.accept_chat_invite(text) TO authenticated;

-- Add conversation_id to chat_messages
ALTER TABLE public.chat_messages ADD COLUMN conversation_id uuid REFERENCES public.conversations(id) ON DELETE CASCADE;
CREATE INDEX idx_chat_messages_conv ON public.chat_messages(conversation_id, created_at);

-- Backfill: create a default conversation for any existing messages
DO $$
DECLARE
  default_conv uuid;
  any_user uuid;
BEGIN
  IF EXISTS (SELECT 1 FROM public.chat_messages WHERE conversation_id IS NULL) THEN
    SELECT id INTO any_user FROM public.profiles ORDER BY created_at LIMIT 1;
    IF any_user IS NOT NULL THEN
      INSERT INTO public.conversations (name, created_by) VALUES ('Geral', any_user) RETURNING id INTO default_conv;
      INSERT INTO public.conversation_members (conversation_id, user_id)
        SELECT default_conv, id FROM public.profiles ON CONFLICT DO NOTHING;
      UPDATE public.chat_messages SET conversation_id = default_conv WHERE conversation_id IS NULL;
    ELSE
      DELETE FROM public.chat_messages WHERE conversation_id IS NULL;
    END IF;
  END IF;
END $$;

ALTER TABLE public.chat_messages ALTER COLUMN conversation_id SET NOT NULL;

-- Replace chat_messages policies to scope by conversation membership
DROP POLICY IF EXISTS "Authenticated can send" ON public.chat_messages;
DROP POLICY IF EXISTS "Authenticated can view chat" ON public.chat_messages;
DROP POLICY IF EXISTS "Sender can soft-delete own" ON public.chat_messages;

CREATE POLICY "Members view messages" ON public.chat_messages FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Members send messages" ON public.chat_messages FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = sender_id AND public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "Sender soft-delete own" ON public.chat_messages FOR UPDATE TO authenticated
  USING (auth.uid() = sender_id) WITH CHECK (auth.uid() = sender_id);

-- Profiles: add username (separate from display_name) — optional, keep display_name
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS username text UNIQUE;

-- Storage policies for avatars bucket (private; users manage own folder; all authenticated can read)
CREATE POLICY "Authenticated read avatars" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'avatars');
CREATE POLICY "Users upload own avatar" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Users update own avatar" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Users delete own avatar" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
