
REVOKE EXECUTE ON FUNCTION public.is_conversation_member(uuid, uuid) FROM public, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.accept_chat_invite(text) FROM public, anon;
-- keep authenticated for accept_chat_invite (intentionally callable)
GRANT EXECUTE ON FUNCTION public.accept_chat_invite(text) TO authenticated;
