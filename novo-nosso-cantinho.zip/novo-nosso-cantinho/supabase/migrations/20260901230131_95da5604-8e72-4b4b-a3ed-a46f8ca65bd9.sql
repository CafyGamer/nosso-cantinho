drop table if exists public.chat_invites;
drop table if exists public.chat_messages;
drop table if exists public.conversation_members;
drop table if exists public.conversations;
drop function if exists public.accept_chat_invite(text);
drop function if exists public.is_conversation_member(uuid, uuid);