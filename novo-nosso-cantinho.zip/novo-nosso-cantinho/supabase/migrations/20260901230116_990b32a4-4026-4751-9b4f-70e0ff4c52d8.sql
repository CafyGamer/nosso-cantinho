create policy "memories_storage_select" on storage.objects for select to anon, authenticated using (bucket_id = 'memories');
create policy "memories_storage_insert" on storage.objects for insert to anon, authenticated with check (bucket_id = 'memories');
create policy "memories_storage_delete" on storage.objects for delete to anon, authenticated using (bucket_id = 'memories');