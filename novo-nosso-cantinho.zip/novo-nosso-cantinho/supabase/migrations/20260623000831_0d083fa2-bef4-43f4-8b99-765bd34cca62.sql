
-- chat-media: authenticated read/upload; only sender can delete
CREATE POLICY "auth read chat-media" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'chat-media');
CREATE POLICY "auth upload chat-media" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'chat-media' AND owner = auth.uid());
CREATE POLICY "owner delete chat-media" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'chat-media' AND owner = auth.uid());

-- memories bucket: authenticated read/upload; only uploader or app-owner can delete
CREATE POLICY "auth read memories storage" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'memories');
CREATE POLICY "auth upload memories storage" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'memories' AND owner = auth.uid());
CREATE POLICY "uploader or owner deletes memories storage" ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'memories' AND (
      owner = auth.uid()
      OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.is_owner = true)
    )
  );
