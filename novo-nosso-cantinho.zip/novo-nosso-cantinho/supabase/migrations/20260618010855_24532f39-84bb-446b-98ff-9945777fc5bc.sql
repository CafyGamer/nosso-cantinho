
CREATE TABLE public.memories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('photo','note')),
  image_url TEXT,
  caption TEXT,
  note_text TEXT,
  author TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.memories TO anon, authenticated;
GRANT ALL ON public.memories TO service_role;
ALTER TABLE public.memories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view memories" ON public.memories FOR SELECT USING (true);
CREATE POLICY "Anyone can insert memories" ON public.memories FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can view memory images" ON storage.objects FOR SELECT USING (bucket_id = 'memories');
CREATE POLICY "Anyone can upload memory images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'memories');
